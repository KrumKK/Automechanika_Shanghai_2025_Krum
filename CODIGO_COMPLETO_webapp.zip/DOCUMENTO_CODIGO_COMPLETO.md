# Documento con todo el código – Webapp Automechanika Shanghai 2025

**Proyecto:** Seguimiento Automechanika Shanghai 2025 - Lizarte  
**Versión:** V12  
**Fecha:** 28 de enero de 2025  

Este documento reúne el código de los archivos principales del proyecto para que puedas consultarlo o descargarlo en un solo sitio.

---

## Índice

1. [.github/workflows/deploy.yml](#1-githubworkflowsdeployyml)
2. [GUIA_USO_APLICACION.md](#2-guia_uso_aplicacionmd)
3. [datos.json e index.html](#3-datosjson-e-indexhtml)

---

## 1. .github/workflows/deploy.yml

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches:
      - main
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write  # ⚠️ ESTE ES EL PERMISO QUE FALTABA

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      
      - name: Setup Node.js (si es necesario)
        uses: actions/setup-node@v4
        with:
          node-version: '20'
      
      # Aquí irían tus pasos de build si los tienes
      - name: Build
        run: echo "Build completado"
        # Ejemplo: npm install && npm run build

  report-build-status:
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Report build status
        run: echo "Build status reportado"

  deploy:
    runs-on: ubuntu-latest
    needs: build
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      
      - name: Setup Pages
        uses: actions/configure-pages@v4
      
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: '.'  # Ajusta esto según tu estructura (ej: './dist' si tienes build)
      
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

---

## 2. GUIA_USO_APLICACION.md

El contenido completo de la guía está en el archivo **GUIA_USO_APLICACION.md** en la raíz del proyecto (401 líneas). Incluye:

- Introducción
- Pantalla inicial (Splash)
- Dashboard y estadísticas
- Pestañas (Reuniones, Info Adicional, Nuevos Coches, Ahorros, Guía, Configuración)
- Sistema de clasificación y seguimiento
- Filtros, exportación, preguntas frecuentes

Para tener la guía en un solo documento: abre **GUIA_USO_APLICACION.md** en tu editor o en la carpeta del proyecto.

---

## 3. datos.json e index.html

Por su tamaño, estos archivos no se incluyen aquí en bloque, pero forman parte del mismo proyecto y están en la misma carpeta:

| Archivo      | Ubicación        | Líneas aprox. | Descripción                          |
|-------------|------------------|---------------|--------------------------------------|
| **datos.json** | Raíz del proyecto | ~1505         | Datos de reuniones, adicional, nuevos coches, ahorros |
| **index.html** | Raíz del proyecto | ~5775         | Aplicación completa (HTML, CSS, JavaScript) |

### Cómo descargar todo el código de una vez

1. **Carpeta del proyecto**  
   La ruta de tu proyecto es:  
   `c:\Users\knikolaev\Desktop\webapp_FINAL_V3`  
   Ahí tienes:
   - `index.html`
   - `datos.json`
   - `GUIA_USO_APLICACION.md`
   - `.github/workflows/deploy.yml`
   - carpeta `fotos/`

2. **ZIP con todo el código**  
   En la misma carpeta se ha generado el archivo **CODIGO_COMPLETO_webapp.zip**, que contiene una copia de los archivos de código anteriores (y opcionalmente la estructura de carpetas).  
   Descarga o copia **CODIGO_COMPLETO_webapp.zip** para tener todo el código en un solo archivo.

3. **Desde el navegador**  
   Si la app está publicada (por ejemplo en GitHub Pages), puedes usar “Guardar página como” en `index.html` para guardar la aplicación en un solo archivo (incluye el HTML/CSS/JS; los datos se cargan desde `datos.json`).

---

## Resumen de archivos del proyecto

- **index.html** – Aplicación web (interfaz, estilos, lógica, export Word/JSON, splash).
- **datos.json** – Datos base: reuniones, info adicional, nuevos coches, ahorros.
- **GUIA_USO_APLICACION.md** – Guía de uso en Markdown.
- **.github/workflows/deploy.yml** – Workflow de GitHub Actions para desplegar en GitHub Pages.
- **fotos/** – Imágenes de reuniones y galería.

Si necesitas una copia de **datos.json** o **index.html** en otro formato o solo un fragmento concreto, indícalo y se puede preparar.

---

*Documento generado para el proyecto webapp_FINAL_V3 – Lizarte Automechanika Shanghai 2025.*
